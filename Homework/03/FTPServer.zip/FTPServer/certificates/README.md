In case you come across this, these certificates are not used in production anywhere.

Feel free to do whatever you want with it tbh.

The password to the keystore.jks is password btw.


thx for ur attention, ur all very cute. Except tom, tom u r not cute.