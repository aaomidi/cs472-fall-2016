package com.aaomidi.ftpserver.util;

public enum Type {
    CONTROL,
    DATA,
    LOCAL,
}
