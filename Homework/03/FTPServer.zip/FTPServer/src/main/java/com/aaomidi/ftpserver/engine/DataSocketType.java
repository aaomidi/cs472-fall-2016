package com.aaomidi.ftpserver.engine;

public enum DataSocketType {
    NONE,
    ACTIVE,
    PASSIVE,
    EXTENDED_ACTIVE,
    EXTENDED_PASSIVE
}
