For homework three, look at the files appended with hw3

eg:
```
hw3_questions.md
hw3_readme.md

hw4_questions.md
hw4_readme.md
```